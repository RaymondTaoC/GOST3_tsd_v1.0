% Monte-Carlo ray tracing: sub-function

function [svs,svu,snv,out_r_jd]=leaf_s(leaf_length,leaf_shape,szap,vzap,azimuth_sun,azimuth_view,out_r_jd,out_r_leaf_normal,coord,nnr)

szap_p=szap*pi/180;

vv=[-sin(vzap*pi/180),0,-cos(vzap*pi/180)];

delta=azimuth_sun-azimuth_view;
if delta<0 
    delta=delta+360;
end

vv_new=[vv(1)*cos(delta*pi/180)+vv(2)*cos(pi/2-delta*pi/180),vv(1)*cos(pi/2+delta*pi/180)+vv(2)*cos(delta*pi/180),vv(3)];
sv_new=sview(szap,0); 
leaf_center_new=[coord(:,1)*cos(delta*pi/180)+coord(:,2)*cos(pi/2-delta*pi/180),coord(:,1)*cos(pi/2+delta*pi/180)+coord(:,2)*cos(delta*pi/180),coord(:,3)]; 
leaf_normal_new=[nnr(:,1)*cos(delta*pi/180)+nnr(:,2)*cos(pi/2-delta*pi/180),nnr(:,1)*cos(pi/2+delta*pi/180)+nnr(:,2)*cos(delta*pi/180),nnr(:,3)]; 
jd_new=[out_r_jd(:,1)*cos(delta*pi/180)+out_r_jd(:,2)*cos(pi/2-delta*pi/180),out_r_jd(:,1)*cos(pi/2+delta*pi/180)+out_r_jd(:,2)*cos(delta*pi/180),out_r_jd(:,3)];  
r_leaf_normal_new=[out_r_leaf_normal(:,1)*cos(delta*pi/180)+out_r_leaf_normal(:,2)*cos(pi/2-delta*pi/180),out_r_leaf_normal(:,1)*cos(pi/2+delta*pi/180)+out_r_leaf_normal(:,2)*cos(delta*pi/180),out_r_leaf_normal(:,3)]; 

n_1_coord_new=[leaf_center_new(:,1).*cos(pi/2-szap_p)+leaf_center_new(:,3).*cos(szap_p), leaf_center_new(:,2), leaf_center_new(:,1).*cos(pi-szap_p)+leaf_center_new(:,3).*cos(pi/2-szap_p)];
r_point_new=[jd_new(:,1).*cos(pi/2-szap_p)+jd_new(:,3).*cos(szap_p), jd_new(:,2), jd_new(:,1).*cos(pi-szap_p)+jd_new(:,3).*cos(pi/2-szap_p)]; 

svs=0;
svu=0;
snv=0;

if leaf_shape==1
    
    size_jd=size(out_r_jd);
    for i=1:size_jd(1)
        
        keep_1=find(abs(jd_new(i,2)-leaf_center_new(:,2))<=leaf_length & (jd_new(i,3)-leaf_center_new(:,3))<leaf_length & abs(r_point_new(i,3)-n_1_coord_new(:,3))<=leaf_length);
        n_1_coord=leaf_center_new(keep_1,:); 
        n_1_nnr=leaf_normal_new(keep_1,:); 
        
        size_n_1=size(keep_1);
        yj=repmat(jd_new(i,2),size_n_1(1),1);
        xj=(n_1_nnr(:,3).*jd_new(i,1).*cos(szap_p)+n_1_coord(:,1).*n_1_nnr(:,1).*sin(szap_p)-n_1_nnr(:,2).*sin(szap_p).*(yj-n_1_coord(:,2))-n_1_nnr(:,3).*sin(szap_p).*(jd_new(i,3)-n_1_coord(:,3)))./(n_1_nnr(:,1).*sin(szap_p)+n_1_nnr(:,3).*cos(szap_p));
        zj=(n_1_nnr(:,1).*jd_new(i,3).*sin(szap_p)+n_1_coord(:,3).*n_1_nnr(:,3).*cos(szap_p)-n_1_nnr(:,2).*cos(szap_p).*(yj-n_1_coord(:,2))-n_1_nnr(:,1).*cos(szap_p).*(jd_new(i,1)-n_1_coord(:,1)))./(n_1_nnr(:,1).*sin(szap_p)+n_1_nnr(:,3).*cos(szap_p));
        
        sov_m_length=((xj-n_1_coord(:,1)).^2+(yj-n_1_coord(:,2)).^2+(zj-n_1_coord(:,3)).^2).^0.5; 
        
        xh=find(sov_m_length<=leaf_length & zj-jd_new(i,3)>0.00001); 
        size_xh=size(xh);
        if size_xh(1)==0 
            
            flag_2=isview(r_leaf_normal_new(i,:),sv_new,vv_new);
            if flag_2==1
                svs=svs+1; 
                out_r_jd(i,4)=1; 
            end
            if flag_2==0
                svu=svu+1; 
            end
            
        else 
            snv=snv+1; 
        end
        
    end
    
end

if leaf_shape==2 
    
    size_jd=size(out_r_jd); 
    for i=1:size_jd(1) 
        
        keep_1=find(abs(jd_new(i,2)-leaf_center_new(:,2))<=leaf_length & (jd_new(i,3)-leaf_center_new(:,3))<leaf_length & abs(r_point_new(i,3)-n_1_coord_new(:,3))<=leaf_length);
        n_1_coord=leaf_center_new(keep_1,:); 
        
        xs=(sv_new(1,2).^2+sv_new(1,3).^2).*jd_new(i,1)+sv_new(1,1).^2.*n_1_coord(:,1)+sv_new(1,2).*sv_new(1,1).*(n_1_coord(:,2)-jd_new(i,2))+sv_new(1,3).*sv_new(1,1).*(n_1_coord(:,3)-jd_new(i,3));
        ys=(sv_new(1,1).^2+sv_new(1,3).^2).*jd_new(i,2)+sv_new(1,2).^2.*n_1_coord(:,2)+sv_new(1,1).*sv_new(1,2).*(n_1_coord(:,1)-jd_new(i,1))+sv_new(1,3).*sv_new(1,2).*(n_1_coord(:,3)-jd_new(i,3));
        zs=(sv_new(1,1).^2+sv_new(1,2).^2).*jd_new(i,3)+sv_new(1,3).^2.*n_1_coord(:,3)+sv_new(1,1).*sv_new(1,3).*(n_1_coord(:,1)-jd_new(i,1))+sv_new(1,2).*sv_new(1,3).*(n_1_coord(:,2)-jd_new(i,2));
        
        sov_m_length=((xs-n_1_coord(:,1)).^2+(ys-n_1_coord(:,2)).^2+(zs-n_1_coord(:,3)).^2).^0.5; 
        xh=find(sov_m_length<=leaf_length); 
        
        if jd_new(i,3)>max(zs(xh)) 
            svs=svs+1; 
            out_r_jd(i,4)=1; 
        else
            snv=snv+1; 
        end
        
    end
    
end
