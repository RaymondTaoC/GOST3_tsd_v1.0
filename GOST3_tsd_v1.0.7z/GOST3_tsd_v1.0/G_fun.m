% Geometric-Opeical: sub-function

function [G_0_90,G_crown_s,G_crown_v]=G_fun(f_theta_L,leaf_shape,szap,vzap)

if leaf_shape==1
    theta_L=0:90;
    for i=1:91
        for k=1:91
            if theta_L(k)<=(90-(i-1))
                K(k)=cos(theta_L(k)*pi/180)*sin((90-(i-1))*pi/180);
            else
                temp=acos(cot(theta_L(k)*pi/180)*tan((90-(i-1))*pi/180));
                K(k)=2/pi*sin(theta_L(k)*pi/180)*cos((90-(i-1))*pi/180)*sin(temp)+(1-2*temp/pi)*cos(theta_L(k)*pi/180)*sin((90-(i-1))*pi/180);
            end
        end
        G_0_90(i)=sum(K.*f_theta_L);
    end
    G_crown_v=G_0_90(fix(vzap)+1);
    G_crown_s=G_0_90(fix(szap)+1);
else
    G_0_90=f_theta_L.*0+1;
    G_crown_v=1;
    G_crown_s=1;
end