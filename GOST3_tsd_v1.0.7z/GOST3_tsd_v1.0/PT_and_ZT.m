% Monte-Carlo ray tracing: sub-function 20220101 by Fan

function [PT_total, PT_1, PT_2, SPT, ratio_2]=PT_and_ZT(szap,vzap,azimuth_view,azimuth_sun,pgaps,pgapv,Pti,Ptj,pvg,ha,hb,r,leaf_shape,Ps,coord,nnr,f)

if vzap==0 
    azimuth_view=0;
end

leaf_length=(Ps/pi)^0.5; 

[SPT, ratio_2, out, out_s]=sunview(ha,hb,r,vzap,szap,azimuth_sun,azimuth_view,leaf_length,coord,nnr,leaf_shape,f); 

if vzap==0
    vzap=0.0000001;
end
if szap==0 
    szap=1;
end

sazi_w=abs(azimuth_sun-azimuth_view); 

Pti=Pti'; 
Ptj=Ptj';
size_pti=size(Pti);

for i=1:size_pti(1)
    pti_i_n(i,1)=sum(Pti(i:end)); 
    ptj_j_n(i,1)=sum(Ptj(i:end));
end

pti_i_n(find(pti_i_n==0))=[];
ptj_j_n(find(ptj_j_n==0))=[];

pti_i_n=pti_i_n./sum(pti_i_n); 
ptj_j_n=ptj_j_n./sum(ptj_j_n); 

out(:,5)=out(:,3).*sin(vzap*pi/180)-out(:,1).*cos(vzap*pi/180); 
out(:,6)=(out(:,1).*cos(sazi_w*pi/180)+out(:,2).*cos(pi/2-sazi_w*pi/180)).*cos(pi-szap*pi/180)+out(:,3).*cos(pi/2-szap*pi/180);

size_out=size(out);

ptj_j_n=fix(ptj_j_n.*size_out(1)); 
ptj_j_n(find(ptj_j_n(:,1)<1))=[];  
ptj_j_n(1)=ptj_j_n(1)+(size_out(1)-sum(ptj_j_n));

size_ptj_j_n=size(ptj_j_n); 

out=sortrows(out,-5); 
if size_ptj_j_n(1)==1 
    out(:,7)=1; 
    out(:,9)=1; 
else 
    cnb=1; 
    for i=1:size_ptj_j_n(1)
        if i<size_ptj_j_n(1) 
            out(cnb:(cnb-1+ptj_j_n(i)),7)=i; 
            rto=(pgapv^(i-1)-pgapv^i)/(1-pgapv);
            
            jl=find(out(:,4)==1 & out(:,7)==i); 
            nm=size(jl);
            ntX=round(rto*nm(1)); 
            rand('seed',70); 
            tcX=sortrows([[ones(ntX,1); zeros(nm(1)-ntX,1)] randperm(nm(1))'],2); 
            out(jl,11)=tcX(:,1); 
            
            nt=fix(rto*ptj_j_n(i)); 
            rand('seed',70); 
            tc=sortrows([[ones(nt,1); zeros(ptj_j_n(i)-nt,1)] randperm(ptj_j_n(i))'],2);
            out(cnb:(cnb-1+ptj_j_n(i)),9)=tc(:,1);
            cnb=cnb+ptj_j_n(i);
        else 
            out(cnb:end,7)=i;
            rto=(pgapv^(i-1)-pgapv^i)/(1-pgapv); 
            ntX=fix(rto*nm(1)); 
            last_one=size(out(cnb:end,:)); 
            
            if last_one(1)<ntX 
                ntX=0; 
            end
            rand('seed',70); 
            tcX=sortrows([[ones(ntX,1); zeros(last_one(1)-ntX,1)] randperm(last_one(1))'],2);
            out(cnb:end,11)=tcX(:,1);
            
            nt=round(rto*ptj_j_n(i));
            last_one=size(out(cnb:end,:)); 
            rand('seed',70);
            tc=sortrows([[ones(nt,1); zeros(last_one(1)-nt,1)] randperm(last_one(1))'],2);
            out(cnb:end,9)=tc(:,1);
        end
    end
end

size_os=size(out_s);
pti_i_n=fix(pti_i_n.*size_os(1)); 
pti_i_n(find(pti_i_n==0))=[];
pti_i_n(1)=pti_i_n(1)+(size_os(1)-sum(pti_i_n));

size_pti_i_n=size(pti_i_n);

out_s(:,4)=out_s(:,3).*sin(szap*pi/180)-out_s(:,1).*cos(szap*pi/180); 

out_s=sortrows(out_s,-4); 
if size_pti_i_n(1)==1 
    out_s(:,5)=1;
else
    temp=1;
    for i=1:size_pti_i_n(1)
        if i<size_pti_i_n(1)
            out_s(temp:(temp-1+pti_i_n(i)),5)=i;
            temp=temp+pti_i_n(i);
        else
            out_s(temp:end,5)=i;
        end
    end
end

lsb_up(:,2:3)=out_s(:,4:5);
lsh_dn=[(1:size_out(1))' out(:,6) zeros(size_out(1),1)];
lsh=[lsb_up;lsh_dn];
lsh=sortrows(lsh,-2);
size_lsh=size(lsh);
if lsh(1,3)==0
    lsh(1,3)=1;
end
for i=2:size_lsh(1)
    if lsh(i,3)==0
        lsh(i,3)=lsh(i-1,3);
    end
end
del_t=find(lsh(:,1)==0);
lsh(del_t',:)=[];
lsh=sortrows(lsh,1);
out(:,8)=lsh(:,3);

out=sortrows(out,-6); 
scs=unique(out(:,8));
size_scs=size(scs);
for i=1:size_scs(1)
    rto=(pgaps^(scs(i)-1)-pgaps^scs(i))/(1-pgaps); 
    
    jl=find(out(:,4)==1 & out(:,8)==scs(i)); 
    nm=size(jl);
    nt=round(rto*nm(1)); 
    rand('seed',70);
    tc=sortrows([[ones(nt,1); zeros(nm(1)-nt,1)] randperm(nm(1))'],2);
    out(jl,10)=tc(:,1);
end

out(:,12)=(pgapv.^(out(:,7)-1)-pgapv.^out(:,7))./(1-pgapv).*(pgaps.^(out(:,8)-1)-pgaps.^out(:,8))./(1-pgaps);
fd4=find(out(:,4)==1);
minv=sum(out(fd4,12));

f4=size(find(out(:,4)==1));
f9=size(find(out(:,9)==1));
f10=size(find(out(:,10)==1));
f11=size(find(out(:,11)==1));
ft=size(out);

maxv=min([f11(1) f10(1)]); 
if maxv(1)<minv(1)
    msgbox('maxv(1)<minv(1) in PT_and_ZT.m');
    maxv(1)=minv(1);
end

xi=acos(cos(vzap*pi/180)*cos(szap*pi/180)+sin(vzap*pi/180)*sin(szap*pi/180)*cos(azimuth_sun*pi/180-azimuth_view*pi/180));

temp=(1-xi/pi)*maxv(1)+xi/pi*minv(1); 

PT_total=(temp/f4(1))/(f9(1)/ft(1))*(SPT+ratio_2)*(1-pvg); 
if PT_total>1
    PT_total=1;
end
if PT_total<0
    PT_total=0;
end

PT_1=(temp/f4(1))/(f9(1)/ft(1))*SPT*(1-pvg);
if PT_1>1
    PT_1=1;
end
if PT_1<0
    PT_1=0;
end

PT_2=PT_total-PT_1; 
if PT_2>1
    PT_2=1;
end
if PT_2<0
    PT_2=0;
end
