% Geometric-Opeical: sub-function
function Pnn=poissonf(m)

NN=350; 
Px_tot=0;
Pnn(1,1)=exp(-m); 
Px_tot=Px_tot+Pnn; 

for ak=1:NN 
    Pnn(1,ak+1)=Pnn(1,ak)*m/ak;
    Px_tot=Px_tot+Pnn(1,ak+1);
end

if Px_tot<0.95 
    msgbox('Possible error in Poisson distribution');
end

for k=1:(NN+1) 
    Pnn(1,k)=Pnn(1,k)/Px_tot;
end