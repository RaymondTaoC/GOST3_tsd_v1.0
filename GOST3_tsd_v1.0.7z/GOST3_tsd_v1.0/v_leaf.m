% Monte-Carlo ray tracing: sub-function 20211230 by Fan
function [out_r_jd, out_r_leaf_normal, out_r_coord]=v_leaf(ha,hb,r,leaf_center,leaf_normal,leaf_length,vzap,leaf_shape,f)

r_point=raypoint(ha,hb,r,vzap,f);
vzap=vzap*pi/180; 

out_r_coord=[]; 
out_c=1; 

n_1_coord_new=[leaf_center(:,1).*cos(pi/2-vzap)+leaf_center(:,3).*cos(vzap), leaf_center(:,2), leaf_center(:,1).*cos(pi-vzap)+leaf_center(:,3).*cos(pi/2-vzap)];
r_point_new=[r_point(:,1).*cos(pi/2-vzap)+r_point(:,3).*cos(vzap), r_point(:,2), r_point(:,1).*cos(pi-vzap)+r_point(:,3).*cos(pi/2-vzap)]; 

sizerayp=size(r_point); 

if leaf_shape==1 
    for i=1:sizerayp(1) 
        
        keep_1=find(abs(r_point(i,2)-leaf_center(:,2))<=leaf_length & abs(r_point_new(i,3)-n_1_coord_new(:,3))<=leaf_length); 
        n_1_coord=leaf_center(keep_1,:); 
        n_1_nnr=leaf_normal(keep_1,:);
        
        size_n_1=size(keep_1);
        if size_n_1(1)~=0 
            
            yj=repmat(r_point(i,2),size_n_1(1),1);
            xj=(n_1_nnr(:,3).*r_point(i,1).*cos(vzap)+n_1_coord(:,1).*n_1_nnr(:,1).*sin(vzap)-n_1_nnr(:,2).*sin(vzap).*(yj-n_1_coord(:,2))-n_1_nnr(:,3).*sin(vzap).*(r_point(i,3)-n_1_coord(:,3)))./(n_1_nnr(:,1).*sin(vzap)+n_1_nnr(:,3).*cos(vzap));
            zj=(n_1_nnr(:,1).*r_point(i,3).*sin(vzap)+n_1_coord(:,3).*n_1_nnr(:,3).*cos(vzap)-n_1_nnr(:,2).*cos(vzap).*(yj-n_1_coord(:,2))-n_1_nnr(:,1).*cos(vzap).*(r_point(i,1)-n_1_coord(:,1)))./(n_1_nnr(:,1).*sin(vzap)+n_1_nnr(:,3).*cos(vzap));
            
            sov_m_length=((xj-n_1_coord(:,1)).^2+(yj-n_1_coord(:,2)).^2+(zj-n_1_coord(:,3)).^2).^0.5; 
            
            xh=find(sov_m_length<leaf_length);
            size_xh=size(xh);
            if size_xh(1)~=0 
                leaf_center_n=n_1_coord(xh,:); 
                leaf_normal_n=n_1_nnr(xh,:); 
                leaf_jd=[xj(xh,1) yj(xh,1) zj(xh,1)];
                
                [tempt, jd_pos]=max(leaf_jd(:,3));
                
                out_r_coord(out_c,:)=leaf_center_n(jd_pos,:); 
                out_r_leaf_normal(out_c,:)=leaf_normal_n(jd_pos,:); 
                out_r_jd(out_c,:)=[leaf_jd(jd_pos,:) 0];  
                
                out_c=out_c+1;
            end
        end
    end
end

if leaf_shape==2 
    for i=1:sizerayp(1) 
        
        keep_1=find(abs(r_point(i,2)-leaf_center(:,2))<=leaf_length & abs(r_point_new(i,3)-n_1_coord_new(:,3))<=leaf_length); 
        n_1_coord=leaf_center(keep_1,:);
        
        size_n_1=size(keep_1);
        if size_n_1(1)~=0 
            
            yj=repmat(r_point(i,2),size_n_1(1),1);
            zj=sin(vzap)^2*r_point(i,3)-sin(vzap)*cos(vzap)*(r_point(i,1)-n_1_coord(:,1))+cos(vzap)^2*n_1_coord(:,3);
            xj=cos(vzap)^2*r_point(i,1)-sin(vzap)*cos(vzap)*(r_point(i,3)-n_1_coord(:,3))+sin(vzap)^2*n_1_coord(:,1);
            
            sov_m_length=((xj-n_1_coord(:,1)).^2+(yj-n_1_coord(:,2)).^2+(zj-n_1_coord(:,3)).^2).^0.5;
            
            xh=find(sov_m_length<leaf_length); 
            size_xh=size(xh);
            if size_xh(1)~=0 
                rx=xj(xh,1)+sin(vzap).*(leaf_length^2-sov_m_length(xh,:).^2).^0.5;
                ry=yj(xh,1);
                rz=zj(xh,1)+cos(vzap).*(leaf_length^2-sov_m_length(xh,:).^2).^0.5;
                
                leaf_center_n=n_1_coord(xh,:);
                leaf_jd=[rx ry rz]; 
                
                [tempt, jd_pos]=max(leaf_jd(:,3)); 
                
                out_r_coord(out_c,:)=leaf_center_n(jd_pos,:);  
                out_r_leaf_normal(out_c,:)=[0 0 0];       
                out_r_jd(out_c,:)=[leaf_jd(jd_pos,:) 0];     
                
                out_c=out_c+1;
            end
        end
    end
end

size_out_r_jd=size(out_r_jd);
if size_out_r_jd(1)==0 
    msgbox('Possible error in v_leaf.m: Too sparse leaves!');
end

