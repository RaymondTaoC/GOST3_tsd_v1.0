% Monte-Carlo ray tracing: sub-function 20200523 by Fan

function [coord, nnr, f_theta_L]=tree_develop(ha,hb,r,Ps,lai,b,d,alpha,crown_shape,f_theta)

theta_L=0:90; 
if f_theta==1
    f_theta_L(1,:)=(2*theta_L*pi/180-sin(2*theta_L*pi/180))/pi; 
end
if f_theta==2
    f_theta_L(1,:)=(2*theta_L*pi/180+sin(2*theta_L*pi/180))/pi; 
end
if f_theta==3
    f_theta_L(1,:)=(2*theta_L*pi/180-0.5*sin(4*theta_L*pi/180))/pi; 
end
if f_theta==4
    f_theta_L(1,:)=1-cos(theta_L*pi/180); 
end
if f_theta==5
    f_theta_L(1,:)=2/pi*(theta_L*pi/180); 
end
if f_theta==6 
    readdata=strcat('.\Model_input\leafangledistributionacc.mat'); 
    pp = load(readdata);
    f_theta_L=pp.leafangledistribution;
end

tp=f_theta_L;
for i=2:91 
    f_theta_L(1,i)=tp(:,i)-tp(:,i-1);
end
f_theta_L=[f_theta_L(2:end) f_theta_L(end)];

num=round(lai*b/(d*Ps)); 
coord=leafcenter(num,r,ha,hb,alpha,crown_shape); 

nnr_zenith_num=fix(num.*f_theta_L); 
num_rest=num-sum(nnr_zenith_num); 
nnr_zenith_num(1:num_rest)=nnr_zenith_num(1:num_rest)+1; 

nnr_zenith=[];
nnr_azimuth=[];
for i=0:90 
    nnr_zenith=[nnr_zenith; repmat(i,nnr_zenith_num(i+1),1)]; 
    
    jg=360/nnr_zenith_num(i+1);
    tmp=0:jg:359;
    if nnr_zenith_num(i+1)~=0
        nnr_azimuth=[nnr_azimuth; tmp']; 
    end
    size_tmp=size(tmp); 
    dif=nnr_zenith_num(i+1)-size_tmp(2); 
    if dif>0 
        nnr_azimuth=[nnr_azimuth; zeros(dif,1)+359.5];
    end
end

for i=1:num 
    nnr(i,:)=-sview(nnr_zenith(i,:),nnr_azimuth(i,:)); 
end
