% p theory: sub-function
% Direct and multiple scattering by hemispherical sky radiation (within a sloping canopy)

function SKY_BHRleaf=Sky_leaf(LRT,w,Phemi,GAPhemi,p,Sd,Su)

wL=(LRT(:,2)+LRT(:,3)+LRT(:,5)+LRT(:,6))/2; 

B=(1-p).*Sd./(1-p*wL); 
C=(1-Phemi)*wL*(1-p).*Su./(1-p*wL);
F=GAPhemi+(1-GAPhemi)*wL*(1-p).*Sd./(1-p*wL);
G=(1-GAPhemi)*wL.*(1-p).*Su./(1-p*wL); 
H=F.*w'.*C./(1-w'.*(1-Phemi).*wL.*B);

SKY_BHRleaf=G+H;