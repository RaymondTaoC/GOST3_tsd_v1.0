% Geometric-Opeical: sub-function
function Px=neyman(d,n,m2)

NN=350;
if m2>d/n
    m2=d/n;
end
m1=round(d/(n*m2));

Px(1,1)=exp(-m1*(1-exp(-m2)));
Px_tot=Px(1,1);
for k=2:(NN+1)
    Px(1,k)=0;
    if (k-1)>d/n && Px(1,k-1)<0.00001
        Px(1,k)=0;
    else
        for t=1:(k-1)
            PXX=m1*m2*exp(-m2)/(k-1)*Px(1,k-t);
            for i=2:t
                PXX=PXX*m2/(i-1);
            end
            Px(1,k)=Px(1,k)+PXX;
        end
    end
    Px_tot=Px_tot+Px(1,k);
end

if Px_tot<0.98 
    msgbox('Possible error in Neyman distribution');
end

for k=1:(NN+1)
    Px(1,k)=Px(1,k)/Px_tot;
end