% Geometric-Opeical: sub-function
% Absorption and Albedo
function [direct_abs_background,direct_downward_0,direct_upward_0,diffuse_abs_background,diffuse_downward_0,diffuse_upward_0,Total_abs_background_q,Total_abs_background_p,Total_downward_0_q,...
    Total_downward_0_p,Total_upward_0_q,Total_upward_0_p,direct_abs_foliage,diffuse_abs_foliage,Total_abs_foliage_q,Total_abs_foliage_p,Total_abs_canopy_q,Total_abs_canopy_p,Albedo,Albedo_black,Albedo_White]...
    =A_canopy(pig,LRT,w,Phemi,GAPhemi,p,solar_direct,solar_diffuse,Sd)

%%
wL=(LRT(:,2)+LRT(:,3)+LRT(:,5)+LRT(:,6))/2;

%%
A= pig + (1-pig).*wL.*(1-p).*Sd./(1-p*wL);
B=(1-p).*Sd./(1-p*wL); % 20200518 Fan
F=GAPhemi+(1-GAPhemi)*wL*(1-p).*Sd./(1-p*wL);

%%
direct_abs_background=A.*(1-w')./(1-w'.*(1-Phemi).*wL.*B);

direct_downward_0=A./(1-w'.*(1-Phemi).*wL.*B);

direct_upward_0=A.*w'./(1-w'.*(1-Phemi).*wL.*B);

diffuse_abs_background=F.*(1-w')./(1-w'.*(1-Phemi).*wL.*B);

diffuse_downward_0=F./(1-w'.*(1-Phemi).*wL.*B);

diffuse_upward_0=F.*w'./(1-w'.*(1-Phemi).*wL.*B);

Total_abs_background_q=(solar_direct'.*A+solar_diffuse'.*F).*(1-w')./(1-w'.*(1-Phemi).*wL.*B);
Total_abs_background_p=(solar_direct'.*A+solar_diffuse'.*F).*(1-w')./((1-w'.*(1-Phemi).*wL.*B).*(solar_direct'+solar_diffuse'));

Total_downward_0_q=(solar_direct'.*A+solar_diffuse'.*F)./(1-w'.*(1-Phemi).*wL.*B);
Total_downward_0_p=(solar_direct'.*A+solar_diffuse'.*F)./((1-w'.*(1-Phemi).*wL.*B).*(solar_direct'+solar_diffuse'));

Total_upward_0_q=(solar_direct'.*A+solar_diffuse'.*F).*w'./(1-w'.*(1-Phemi).*wL.*B);
Total_upward_0_p=(solar_direct'.*A+solar_diffuse'.*F).*w'./((1-w'.*(1-Phemi).*wL.*B).*(solar_direct'+solar_diffuse'));

K=(1-Phemi).*(1-wL)./(1-p.*wL);

direct_abs_foliage=(1-pig).*(1-wL)./(1-p.*wL)+A.*w'.*K./(1-w'.*(1-Phemi).*wL.*B);

diffuse_abs_foliage=(1-GAPhemi).*(1-wL)./(1-p.*wL)+F.*w'.*K./(1-w'.*(1-Phemi).*wL.*B);

Total_abs_foliage_q = solar_direct'.*direct_abs_foliage + solar_diffuse'.*diffuse_abs_foliage;
Total_abs_foliage_p = (solar_direct'.*direct_abs_foliage + solar_diffuse'.*diffuse_abs_foliage)./(solar_direct'+solar_diffuse');

Total_abs_canopy_q = Total_abs_background_q + Total_abs_foliage_q;
Total_abs_canopy_p = Total_abs_background_p + Total_abs_foliage_p;

Albedo=1-Total_abs_canopy_p;

Albedo_black = 1 - direct_abs_background - direct_abs_foliage;

Albedo_White = 1 - diffuse_abs_background - diffuse_abs_foliage;
