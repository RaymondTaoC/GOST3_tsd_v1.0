% Geometric-Opeical: sub-function

function ta=ta_vs(r,zap,hb,alpha,crown_shape)

zap=zap*pi/180;

if crown_shape==1 
    ta=pi*r*r*cos(zap)+2*r*hb*sin(zap);
end

if crown_shape==2 
    
    alpha=alpha*pi/180;
    
    if 0<=zap && zap<=alpha
        ta=pi*r*r*cos(zap);
    end
    
    if zap>alpha
        xa=r*cos(zap);
        xb=r*sin(zap)/tan(alpha); 
        yd=r*(xb^2-xa^2)^0.5/xb;
        if r^2>yd^2
            eqtval=r^2*asin(yd/r)+yd*(r^2-yd^2)^0.5;
        end
        if r^2<=yd^2
            eqtval=0;
        end
        tact=2*xb*yd-yd^2*(xb^2-xa^2)^0.5/r-xa/r*eqtval;
        ta=pi*r*r*cos(zap)+tact;
    end
end

if crown_shape==3 
    
    alpha=alpha*pi/180;
    
    if 0<=zap && zap<=alpha
        ta=pi*r*r*cos(zap)+2*r*(hb-r/tan(alpha))*sin(zap);
    end
    
    if zap>alpha
        xa=r*cos(zap); 
        xb=r*sin(zap)/tan(alpha); 
        yd=r*(xb^2-xa^2)^0.5/xb;
        if r^2>yd^2
            eqtval=r^2*asin(yd/r)+yd*(r^2-yd^2)^0.5;
        end
        if r^2<=yd^2
            eqtval=0;
        end
        tact=2*xb*yd-yd^2*(xb^2-xa^2)^0.5/r-xa/r*eqtval;
        ta=pi*r*r*cos(zap)+2*r*(hb-r/tan(alpha))*sin(zap)+tact;
    end
end

if crown_shape==4 
    
    ta=pi*r*(hb/2*sin(zap)^2+r*cos(zap)^2); 
    
end
