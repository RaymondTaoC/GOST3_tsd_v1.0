% Monte-Carlo ray tracing: sub-function

function rayp=raypoint(ha,hb,r,vzap,f)

vzap=vzap*pi/180;

k=10; 
D=(ha+hb)*k;

xmax=r+D*sin(vzap);
xmin=xmax-(hb*sin(vzap)+2*r*cos(vzap))*cos(vzap);
ymax=r;
ymin=-r;
zmax=D*cos(vzap)+ha+hb*sin(vzap)*sin(vzap)+2*r*sin(vzap)*cos(vzap);
zmin=D*cos(vzap)+ha;

if xmax==xmin
    dis_y=(ymax-ymin)/f;
    y=ymin:dis_y:ymax;
    
    dis_z=(zmax-zmin)/f;
    z=zmin:dis_z:zmax;
    
    size_z=size(z);
    x=ones(1,size_z(2))*xmax;
end

if zmax==zmin
    dis_y=(ymax-ymin)/f;
    y=ymin:dis_y:ymax;
    
    dis_x=(xmax-xmin)/f;
    x=xmin:dis_x:xmax;
    
    size_x=size(x);
    z=ones(1,size_x(2))*zmax;
end

if xmax~=xmin && zmax~=zmin
    dis_y=(ymax-ymin)/f;
    y=ymin:dis_y:ymax;
    
    dis_x=(xmax-xmin)/f;
    x=xmin:dis_x:xmax;
    
    z=(x-xmax+zmin.*(xmax-xmin)./(zmin-zmax))./((xmax-xmin)./(zmin-zmax)); 
end

rayp=[];
size_x=size(x);
size_y=size(y);

for i=1:size_y(2)
    temp=repmat(y(i),size_x(2),1);
    temp_rayp=[x',temp,z'];
    rayp=[rayp;temp_rayp];
end
