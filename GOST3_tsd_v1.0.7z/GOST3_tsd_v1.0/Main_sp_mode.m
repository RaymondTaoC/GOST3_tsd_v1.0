% Main: sub-function
function [PT_total,PT_1,PT_2,ZT,PG,ZG,pvg,pig,p_random,p_clumping,omega_sza,omega_vza,leaf_single,soil_single,leaf_multiple,soil_multiple,single_canopy,multiple_canopy,canopy_reflectance_dir,canopy_reflectance_diff,pixel_reflectance,...
    direct_abs_background,direct_downward_0,direct_upward_0,diffuse_abs_background,diffuse_downward_0,diffuse_upward_0,Total_abs_background_p,Total_downward_0_p,...
    Total_upward_0_p,direct_abs_foliage,diffuse_abs_foliage,Total_abs_foliage_p,Total_abs_canopy_p,Albedo,Albedo_black,Albedo_White,Su,Sd]...
    =Main_sp_mode(norp,lai,b,d,n,m2,r,ha,hb,alpha,crown_shape,f_theta,Ps,leaf_shape,gamae,szap,azimuth_sun,vzap,azimuth_view,theta_g,azimuth_dem,LRT_name,w_name,DirectionalScatteringRatio_name)

ratio_name=strcat('.\Model_input\',DirectionalScatteringRatio_name);
pp = load(ratio_name);
ss = whos('-file',ratio_name);
solar_direct=pp.solar_direct;
solar_diffuse=pp.solar_diffuse;
p1=solar_direct'./(solar_direct'+solar_diffuse');
p2=solar_diffuse'./(solar_direct'+solar_diffuse');

s_LRT_name=strcat('.\Model_input\',LRT_name);
pp = load(s_LRT_name);
ss = whos('-file',s_LRT_name);
LRT=pp.(ss.name);
LRT_top=LRT(:,1:3);
LRT_down=LRT(:,4:6)*1; 

s_w_name=strcat('.\Model_input\',w_name);
pp = load(s_w_name);
ss = whos('-file',s_w_name);
w=pp.(ss.name);
soil_BRF=w(:,2)';
w=w(:,2)';

f=100; 

vv=sview(vzap,azimuth_view);
bv=sview(theta_g,azimuth_dem);
vvbv=acos(dot(vv,bv)/(norm(vv)*norm(bv)))*180/pi;

if vvbv<90 
    viewslope=1; 
    
    sv=sview(szap,azimuth_sun); 
    vvsv=acos(dot(sv,bv)/(norm(sv)*norm(bv)))*180/pi; 
    
    if vvsv<90 
        sunslope=1; 
        
        [coord nnr f_theta_L]=tree_develop(ha,hb,r,Ps,lai,b,d,alpha,crown_shape,f_theta);
        
        [PT_total,PT_1,PT_2,ZT,PG,ZG,SPT,pvg,pig,ratio_2,Phemi,GAPhemi,sza,vza,ratio_sky,G_0_90,G_crown_s,G_crown_v]...
            =structureMain(norp,lai,b,d,n,m2,r,ha,hb,alpha,crown_shape,gamae,szap,vzap,theta_g,azimuth_sun,azimuth_view,azimuth_dem,leaf_shape,Ps,coord,nnr,f_theta_L,f);
        
        [p_random,p_random_new,p_clumping]=p_function(G_crown_s,lai,sza,theta_g,leaf_shape,pig,gamae);
        
        [Su Sd]=leaf_prop_up_down(LRT_top,LRT_down,f_theta_L);
        [E_b E_l]=Topo_radiation_corr(sza,szap,azimuth_sun,f_theta_L);
        
        Multi_Reflectance_background=M_background(pig,pvg,LRT,w,Phemi,p_clumping,Sd);
        Multi_DHRleaf=M_leaf(pig,LRT,w,Phemi,p_clumping,Sd,Su);
        SKY_BHRbackground=Sky_background(pvg,LRT,w,Phemi,GAPhemi,p_clumping,Sd);
        SKY_BHRleaf=Sky_leaf(LRT,w,Phemi,GAPhemi,p_clumping,Sd,Su);
        
        leaf_single     = PT_1.* E_l*LRT_top(:,2) + PT_2.* E_l*LRT_top(:,3); 
        
        
        soil_single     = PG.*E_b*soil_BRF'; 
        leaf_multiple   =(1-pvg)*Multi_DHRleaf; 
        soil_multiple   = pvg*Multi_Reflectance_background;
        
        single_canopy   = leaf_single + soil_single;
        multiple_canopy = leaf_multiple + soil_multiple;
        canopy_reflectance_dir  = single_canopy + multiple_canopy;
        canopy_reflectance_diff = pvg.*SKY_BHRbackground*ratio_sky + (1-pvg).*SKY_BHRleaf*ratio_sky;
        pixel_reflectance = p1.*canopy_reflectance_dir  +  p2.*canopy_reflectance_diff;
        
        [direct_abs_background,direct_downward_0,direct_upward_0,diffuse_abs_background,diffuse_downward_0,diffuse_upward_0,Total_abs_background_q,Total_abs_background_p,Total_downward_0_q,Total_downward_0_p...
            Total_upward_0_q,Total_upward_0_p,direct_abs_foliage,diffuse_abs_foliage,Total_abs_foliage_q,Total_abs_foliage_p,Total_abs_canopy_q,Total_abs_canopy_p,Albedo,Albedo_black,Albedo_White]...
            =A_canopy(pig,LRT,w,Phemi,GAPhemi,p_clumping,solar_direct,solar_diffuse,Sd);
        
        omega_sza=-log(pig)*cos(szap*pi/180)/(G_crown_s*lai*cos(theta_g*pi/180));
        omega_vza=-log(pvg)*cos(vzap*pi/180)/(G_crown_v*lai*cos(theta_g*pi/180));
        omega_slope=1;
        
    end
    
    if vvsv>=90 
        sunslope=0;
        message('no direct radiation, Main_sp_mode.m');
    end
end

if vvbv>=90
    viewslope=0; 
    sunslope=[];
    message('no sunlit leaves in view direction, Main_sp_mode.m');
end
