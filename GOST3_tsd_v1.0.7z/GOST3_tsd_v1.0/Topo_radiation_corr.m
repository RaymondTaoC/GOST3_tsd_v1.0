% Geometric-Opeical: sub-function

function [E_b, E_l]=Topo_radiation_corr(sza,szap,azimuth_sun,f_theta_L)

E_b=cos(sza)/cos(szap*pi/180);

temp_para=zeros(91,360);
temp_ratio=zeros(91,360);
E_l=0;

j=1:360; 
for i=1:91
    
    temp_ratio(i,:)=acos(cos((i-1)*pi/180).*cos(szap*pi/180)+sin((i-1)*pi/180).*sin(szap*pi/180).*cos(azimuth_sun.*pi/180-(j-1).*pi/180)); 
    temp_para(i,j)=abs(cos(temp_ratio(i,j)))/cos(szap*pi/180); 
    
    E_l=E_l+sum(temp_para(i,:)/360).*f_theta_L(i); 
    
end
