% Geometric-Opeical: sub-function

function [Su Sd]=leaf_prop_up_down(LRT_top,LRT_down,f_theta_L)

size_LRT=size(LRT_top);
Su=zeros(size_LRT(1),1);
Sd=zeros(size_LRT(1),1);

f_theta_L=f_theta_L./sum(f_theta_L);

for i=1:91 
    
    I=1-0.5*(i-1)/90;
    II=1-I;
    III=II; 
    VI=I;
    
    up_1=I.*LRT_top(:,2)+III.*LRT_top(:,3);
    down_1=II.*LRT_top(:,2)+VI.*LRT_top(:,3);
    
    up_2=I.*LRT_down(:,3)+III.*LRT_down(:,2);
    down_2=II.*LRT_down(:,3)+VI.*LRT_down(:,2);
    
    Su_SingleLeaf(:,i)=(up_1.*0.5+up_2.*0.5)./(up_1.*0.5+up_2.*0.5+down_1.*0.5+down_2.*0.5); 
    Sd_SingleLeaf(:,i)=(down_1.*0.5+down_2.*0.5)./(up_1.*0.5+up_2.*0.5+down_1.*0.5+down_2.*0.5);
    
    Su=Su+Su_SingleLeaf(:,i).*f_theta_L(i);
    Sd=Sd+Sd_SingleLeaf(:,i).*f_theta_L(i);
    
end