% Main: sub-function 20220102 by Fan
function [PT_total,PT_1,PT_2,ZT,PG,ZG,SPT,pvg,pig,ratio_2,Phemi,GAPhemi,sza,vza,ratio_sky,G_0_90,G_crown_s,G_crown_v]...
    =structureMain(norp,lai,b,d,n,m2,r,ha,hb,alpha,crown_shape,gamae,szap,vzap,theta_g,azimuth_sun,azimuth_view,azimuth_dem,leaf_shape,Ps,coord,nnr,f_theta_L,f)

sza=acos(cos(theta_g*pi/180)*cos(szap*pi/180)+sin(theta_g*pi/180)*sin(szap*pi/180)*cos(azimuth_sun*pi/180-azimuth_dem*pi/180));
vza=acos(cos(theta_g*pi/180)*cos(vzap*pi/180)+sin(theta_g*pi/180)*sin(vzap*pi/180)*cos(azimuth_view*pi/180-azimuth_dem*pi/180));

As=b/n*cos(sza)/cos(theta_g*pi/180);  
Av=b/n*cos(vza)/cos(theta_g*pi/180); 

tav=ta_vs(r,vzap,hb,alpha,crown_shape); 
tas=ta_vs(r,szap,hb,alpha,crown_shape);

omegae_crown_s=1; 
omegae_crown_v=1; 

[G_0_90,G_crown_s,G_crown_v]=G_fun(f_theta_L,leaf_shape,szap,vzap);

pgaps=exp(-G_crown_s*omegae_crown_s/gamae*lai*b/(d*tas));
pgapv=exp(-G_crown_v*omegae_crown_v/gamae*lai*b/(d*tav));

m=round(d/n);
Px_p=poissonf(m);
Px_n=neyman(d,n,m2);
if norp==1 
    Px=Px_n;
    [pig_neyman, pig_c_neyman, Pti]=gap_fraction(d,n,Px_n,tas,pgaps,As); 
    [pig_poisson, pig_c_poisson]=gap_fraction(d,n,Px_p,tas,pgaps,As); 
    pig=pig_neyman;
    [pvg unuse Ptj]=gap_fraction(d,n,Px_n,tav,pgapv,Av);
end
if norp==2 
    Px=Px_p;
    [pig_neyman, pig_c_neyman]=gap_fraction(d,n,Px_n,tas,pgaps,As); 
    [pig_poisson, pig_c_poisson, Pti]=gap_fraction(d,n,Px_p,tas,pgaps,As); 
    pig=pig_poisson;
    [pvg unuse, Ptj]=gap_fraction(d,n,Px_p,tav,pgapv,Av);
end

[PT_total, PT_1, PT_2, SPT, ratio_2]=PT_and_ZT(szap,vzap,azimuth_view,azimuth_sun,pgaps,pgapv,Pti,Ptj,pvg,ha,hb,r,leaf_shape,Ps,coord,nnr,f);
[PG,ZG,OmegaT]=PG_and_ZG(tas,pig_c_neyman,pig_c_poisson,norp,pig,pvg,b,d,ha,hb,szap,vzap,theta_g,azimuth_sun,azimuth_view,azimuth_dem);

ZT=1-pvg-PT_total;
if ZT>1
    ZT=1;
end
if ZT<0
    ZT=0;
end

jg=15; 
fg=180/jg+1;
bfg=180/(jg*2)+1;

imat=repmat((1:fg)',1,fg);
jmat=repmat((1:fg),fg,1);  
dis=round(((imat-bfg).^2+(jmat-bfg).^2).^0.5); 

for i=1:fg 
    for j=1:fg 
        norm_1=[1-bfg,bfg-bfg];
        norm_2=[i-bfg,j-bfg];
        if j<=bfg
            azi_m(i,j)=acos(dot(norm_1,norm_2)/(norm(norm_1)*norm(norm_2)))*180/pi; 
        end
        if j>bfg
            azi_m(i,j)=360-acos(dot(norm_1,norm_2)/(norm(norm_1)*norm(norm_2)))*180/pi; 
        end
    end
end
azi_m((fg-1)/2+1,(fg-1)/2+1)=0; 

za_s=dis*jg; 
za_s(find(za_s>90))=nan; 
za_h=acos(cos(theta_g*pi/180).*cos(za_s*pi/180)+sin(theta_g*pi/180).*sin(za_s*pi/180).*cos(azi_m*pi/180-(azimuth_dem*pi/180)))*180/pi; 
za_h_k=za_h;
za_h_k(find(za_h>90))=180-za_h(find(za_h>90)); 

A_s=b/n*cos(za_h_k*pi/180)/cos(theta_g*pi/180);

for i=1:fg 
    for j=1:fg 
        
        if isnan(za_h(i,j))==1
            G_s(i,j)=nan;
        else
            if za_h(i,j)<=90 
                G_s(i,j)=G_0_90(fix(za_h(i,j))+1);
                ta_s(i,j)=ta_vs(r,za_h(i,j),hb,alpha,crown_shape); 
            end
            if za_h(i,j)>90 
                G_s(i,j)=G_0_90(fix(180-za_h(i,j))+1); 
                ta_s(i,j)=ta_vs(r,180-za_h(i,j),hb,alpha,crown_shape); 
            end
        end
        
    end
end
if leaf_shape==2 
    G_s=G_s.*0+1; 
end

omegae_crown=dis.*0+1;
pgap_s=exp(-G_s.*omegae_crown/gamae*lai*b./(d*ta_s));

gap_fraction_s=dis.*0;
for i=1:fg
    for j=1:fg
        if isnan(za_h(i,j))==1
            gap_fraction_s(i,j)=nan;
        else
            gap_fraction_s(i,j)=gap_fraction(d,n,Px,ta_s(i,j),pgap_s(i,j),A_s(i,j));
        end
    end
end

zas90pos=find(za_s<90); 
zah90pos=find(za_h<90); 

Phemi=mean(gap_fraction_s(zas90pos));
GAPhemi=mean(gap_fraction_s(zah90pos));

sizezas=size(zas90pos);
sizezah=size(zah90pos);
ratio_sky=sizezah(1)/sizezas(1);
