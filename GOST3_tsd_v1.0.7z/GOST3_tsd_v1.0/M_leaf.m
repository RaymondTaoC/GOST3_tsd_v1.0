% p theory: sub-function
% Multiple scattering from leaves
function Multi_DHRleaf=M_leaf(pig,LRT,w,Phemi,p,Sd,Su)

wL=(LRT(:,2)+LRT(:,3)+LRT(:,5)+LRT(:,6))/2;
A= pig + (1-pig).*wL.*(1-p).*Sd./(1-p*wL);
B=(1-p).*Sd./(1-p*wL);
C=(1-Phemi).*wL*(1-p).*Su./(1-p*wL);

Multi_DHRleaf=((1-pig)*wL*p.*wL*(1-p).*Su)./(1-p*wL)+A.*w'.*C./(1-w'.*(1-Phemi).*wL.*B);