% Monte-Carlo ray tracing: sub-function
function coord=leafcenter(num,r,ha,hb,alpha,crown_shape)

beishu=num*100; 

rand('state', 0);
dt=rand(beishu,3);

x=3*r.*dt(1:beishu,1)-1.5*r;
y=3*r.*dt(1:beishu,2)-1.5*r;
z=3/2*(ha+hb).*dt(1:beishu,3);

if crown_shape==1 
    posi=find(z>=ha & z<=(ha+hb) & (x.^2+y.^2).^0.5<=r);
    size_posi=size(posi);
    if size_posi(1)>=num
        coord=[x(posi(1:num)) y(posi(1:num)) z(posi(1:num))]; 
    else
        msgbox('Possible error in leaf positions');
    end
end

if crown_shape==2 
    posi=find(z>=ha & z<=(ha+hb) & ((x.^2+y.^2).^0.5)./(ha+hb-z)<=r/hb);
    size_posi=size(posi);
    if size_posi(1)>=num
        coord=[x(posi(1:num)) y(posi(1:num)) z(posi(1:num))]; 
    else
        msgbox('Possible error in leaf positions');
    end
end

if crown_shape==3 
    posi=find((z>=ha & z<=(ha+hb-r/tan(alpha*pi/180)) & (x.^2+y.^2).^0.5<=r) | (z>(ha+hb-r/tan(alpha*pi/180)) & z<=(ha+hb) & atan(((x.^2+y.^2).^0.5)./(ha+hb-z))<=alpha*pi/180));
    size_posi=size(posi);
    if size_posi(1)>=num
        coord=[x(posi(1:num) ) y(posi(1:num)) z(posi(1:num))];
    else
        msgbox('Possible error in leaf positions');
    end
end

if crown_shape==4 
    posi=find((x.^2+y.^2)./r^2+(z-ha-hb/2).^2./(hb/2)^2<=1);
    size_posi=size(posi);
    if size_posi(1)>=num
        coord=[x(posi(1:num) ) y(posi(1:num)) z(posi(1:num))]; 
    else
        msgbox('Possible error in leaf positions');
    end
end
