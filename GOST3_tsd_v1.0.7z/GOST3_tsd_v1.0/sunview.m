% Monte-Carlo ray tracing: sub-function 20191003 by Fan

function [ratio_1, ratio_2, out_r_jd, out_r_jd_p]=sunview(ha,hb,r,vzap,szap,azimuth_sun,azimuth_view,leaf_length,coord,nnr,leaf_shape,f)

[out_r_jd, out_r_leaf_normal, xxx]=v_leaf(ha,hb,r,coord,nnr,leaf_length,vzap,leaf_shape,f);

[out_r_jd_p, yyy, zzz]=v_leaf(ha,hb,r,coord,nnr,leaf_length,szap,leaf_shape,f);

[svs,svu,snv,out_r_jd]=leaf_s(leaf_length,leaf_shape,szap,vzap,azimuth_sun,azimuth_view,out_r_jd,out_r_leaf_normal,coord,nnr); 

ratio_1=svs/(svs+svu+snv);
ratio_2=svu/(svs+svu+snv); 