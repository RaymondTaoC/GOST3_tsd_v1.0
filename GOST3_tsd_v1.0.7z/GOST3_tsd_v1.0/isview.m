% Monte-Carlo ray tracing: sub-function

function isviewed=isview(lv,sv,vv)

svlv=acos(dot(sv,lv)/(norm(sv)*norm(lv)))*180/pi;
vvlv=acos(dot(vv,lv)/(norm(vv)*norm(lv)))*180/pi;

if svlv<90 && vvlv<90
    isviewed=1; 
end

if svlv<90 && vvlv>=90
    isviewed=0; 
end

if svlv==90
    isviewed=0; 
end

if svlv>90 && vvlv<=90
    isviewed=0; 
end

if svlv>90 && vvlv>90
    isviewed=1;
end

