% p theory: sub-function
% recollision probability for random vs. clumping leaves
function [p_random,p_random_new,p_clumping]=p_function(G_crown_s,lai,sza,theta_g,leaf_shape,pig_clumping,gamae)

LAI_slope=lai*cos(theta_g*pi/180);

pig_random=exp(-G_crown_s*LAI_slope/cos(sza));

pig_diff=pig_clumping-pig_random;
if pig_diff<0
    pig_diff=0;
    warning('pig_clumping-pig_random<0 in p_function');
end

lai_p=LAI_slope/(1-pig_diff);

pmax=0.88;
kk=0.7;
bb=0.75;
if leaf_shape==1
    
    p_random_new=pmax*(1-exp(-kk*lai_p^bb));
    
    p_random=pmax*(1-exp(-kk*LAI_slope^bb));
    
end

if leaf_shape==2 
    
    p_1=pmax*(1-exp(-kk*(lai_p)^bb));

    psh=1-1/(pi*gamae);
    p_random_new=psh+(1-psh)*p_1;
    
    p=pmax*(1-exp(-kk*(LAI_slope)^bb));

    psh=1-1/(pi*gamae);
    p_random=psh+(1-psh)*p;
    
end

p_clumping=pig_diff*p_random_new*((1-pig_diff)/1) + (1-pig_diff)*p_random_new;