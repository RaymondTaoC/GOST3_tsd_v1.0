% Geometric-Opeical: sub-function
function [PG,ZG,OmegaT]=PG_and_ZG(tas,pig_c_neyman,pig_c_poisson,norp,pig,pvg,b,d,ha,hb,szap,vzap,theta_g,azimuth_sun,azimuth_view,azimuth_dem)

sza=acos(cos(theta_g*pi/180)*cos(szap*pi/180)+sin(theta_g*pi/180)*sin(szap*pi/180)*cos(azimuth_sun*pi/180-azimuth_dem*pi/180)); 
xi=acos(cos(vzap*pi/180)*cos(szap*pi/180)+sin(vzap*pi/180)*sin(szap*pi/180)*cos(azimuth_sun*pi/180-azimuth_view*pi/180));

if norp==1
    OmegaT = log(pig_c_neyman)/log(pig_c_poisson);
end

if norp==2
    OmegaT = 1;
end

Lt=OmegaT*tas*d/(b*cos(sza)/cos(theta_g*pi/180)); 
Wt=tas^0.5; 
H=(ha+hb)*cos(theta_g*pi/180)/cos(sza); 

if xi<pi
    lambda_m=H*tan(xi);
end
if xi>=pi
    lambda_m=0;
end

Cold=pig*pvg;
Hot=pig;

if xi<=pi/2
    IN1=0; 
    IN2=0; 
    FLAG_IN1=0;
    FLAG_IN2=0;
    MAX=200000; 
    INC=0.1;
    for i=0:MAX
        if (lambda_m+INC*i)==0 
            IN2=1;
            IN1=0;
            break;
        else 
            IN1=IN1+exp(-Lt*(1+(lambda_m+INC*i)/Wt))/atan((lambda_m+INC*i)/H); 
            IN2=IN2+exp(-Lt*(1+(lambda_m+INC*i)/Wt));
            if FLAG_IN1==IN1 && FLAG_IN2==IN2 
                i=MAX;
            end
            FLAG_IN1=IN1;
            FLAG_IN2=IN2;
        end
    end
    Ft=0;
    if IN2~=0
        Ft=1-IN1/IN2*xi; 
    end
    if xi<0.0001
        Ft=1;
    end
    PG=Cold+(Hot-Cold)*Ft; 
else
    Ft=0;
    PG=Cold;
end

ZG=pvg-PG; 

if PG<0
    PG=0;
end
if PG>1
    PG=1;
end
if ZG<0
    ZG=0;
end
if ZG>1
    ZG=1;
end
