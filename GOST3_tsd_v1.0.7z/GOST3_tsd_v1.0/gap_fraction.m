% Geometric-Opeical: sub-function
% Gap fraction on canopy level (Pvg and Pig)

function [pvgorpig, pvgorpig_c, Ptiorj]=gap_fraction(d,n,px,ta,pgap_crown,A)

NN=350;
m=d/n;

pvgorpig_c=0;
tat=ta;
for i=1:NN
    if i>m
        tat=ta*m/i;
    end
    if tat>A
        tat=A;
    end
    pvgorpig_c=pvgorpig_c+px(i+1)*(1-tat/A)^i;
end

aaa=ta;
P=0;
for j=1:NN 
    Ptiorj(j)=0;
    for i=j:NN 
        Ptiorj_temp(i)=0;
        if i>m && Ptiorj_temp(i-1)<0.000000001 && i~=j
            Ptiorj_temp(i)=0;
        else
            aa=aaa;
            if i>m 
                aa=aaa*m/i;
            end
            if aaa>A
                aa=A; 
            end
            PNN=px(i+1); 
            if i~=j
                for v=1:(i-j) 
                    PNN=PNN*(j+v)/v*(1-aa/A);
                end
            end
            Ptiorj_temp(i)=PNN*(aa/A)^j;
        end
        Ptiorj(j)=Ptiorj_temp(i)+Ptiorj(j);
    end
    P=P+Ptiorj(j)*pgap_crown^j;
end

pvgorpig=pvgorpig_c+P;

if pvgorpig<0
    pvgorpig=0;
end

if pvgorpig>1
    pvgorpig=1;
end