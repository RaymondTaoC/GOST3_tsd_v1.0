% p theory: sub-function
% Multiple scattering from background
function Multi_Reflectance_background=M_background(pig,pvg,LRT,w,Phemi,p,Sd)

wL=(LRT(:,2)+LRT(:,3)+LRT(:,5)+LRT(:,6))/2;

A= pig + (1-pig).*wL.*(1-p).*Sd./(1-p*wL);
B=(1-p).*Sd./(1-p*wL);

Multi_Reflectance_background=w'.*pvg.*(A-pig+A.*w'.*(1-Phemi).*wL.*B./(1-w'.*(1-Phemi).*wL.*B));