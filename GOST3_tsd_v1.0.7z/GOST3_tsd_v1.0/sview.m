% Monte-Carlo ray tracing: sub-function

function sv=sview(szap,sazi)

szap=szap*pi/180;
sazi=sazi*pi/180;

if sazi>=0 && sazi<pi/2
    sv=[-sin(szap).*cos(sazi) -sin(szap).*sin(sazi) -cos(szap)];
end

if sazi>=pi/2 && sazi<pi
    sv=[sin(szap).*cos(pi-sazi) -sin(szap).*sin(pi-sazi) -cos(szap)];
end

if sazi>=pi && sazi<pi*3/2
    sv=[sin(szap).*cos(sazi-pi) sin(szap).*sin(sazi-pi) -cos(szap)];
end

if sazi>=pi*3/2 && sazi<pi*2
    sv=[-sin(szap).*cos(2*pi-sazi) sin(szap).*sin(2*pi-sazi) -cos(szap)];
end